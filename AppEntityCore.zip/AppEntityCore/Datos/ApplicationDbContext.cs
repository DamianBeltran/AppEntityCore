﻿using AppEntityCore.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography.X509Certificates;

namespace AppEntityCore.Datos
{
    public class ApplicationDbContext:DbContext // calse que ereda de db context
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> opciones) : base(opciones)
        {
             
        }
        // Aqui vamos a escribir los modelos 
        public DbSet<Categoria> Categorias { get; set; }

        public DbSet<Articulo> Articulos { get; set; }
    }
}
