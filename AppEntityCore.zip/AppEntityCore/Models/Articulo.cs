﻿namespace AppEntityCore.Models
{
    public class Articulo
    {
        public int IdArticulo { get; set; }  
        public string? TituloArticulo { get; set; }
            
        public string? Descripcion { get; set; }

        public string? fecha { get; set; }
    }
}
